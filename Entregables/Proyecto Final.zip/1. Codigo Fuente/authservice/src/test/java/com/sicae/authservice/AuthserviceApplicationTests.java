package com.sicae.authservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
